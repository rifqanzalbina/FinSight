class TaxEstimator:
    def __init__(self, country = "Indonesia"):
        """
            Initialize the tax estimator with default tax brackets for the specified country. 
            :param country: The country whose tax system to use (default : Indonesia)
        """

        self.country = country
        self.deductions = []

        # Default tax brackets set to Indonesia's progressive tax rates
        if country.lower() == "indonesia":
